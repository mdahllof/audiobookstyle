import pandas as pd

from expaux.dataformatting import make_dir
from pop_exps.lex_comparison import make_cles_tables, make_ranked_lists
from pop_exps.plotting_style import scatter_raw2


def make_stylometric_scatter_plots(dicts_dir, wdir):
    feats_csv1 = dicts_dir + 'gram_relfrqs.csv'
    feats_csv2 = dicts_dir + 'struct_stats.csv'
    datafr1 = pd.read_csv(feats_csv1, header=0, encoding='utf-8')
    datafr2 = pd.read_csv(feats_csv2, header=0, encoding='utf-8')
    datafr2 = datafr2.loc[:, 'wc':]
    datafr = pd.concat([datafr1, datafr2], axis=1)
    name1 = {'SvB_BS_188', 'SvB_BS_211', 'SvB_BS_212', 'SvB_BS_307',
             'SvB_BS_300', 'SvB_BS_272', 'bstream_005', 'bstream_017',
             'bstream_038', 'SvB_BS_300', 'SvB_BS_293', 'SvB_BS_202',
             'bstream_031', 'bstream_051'}
    name2 = {'SvB_BS_300', 'SvB_BS_281', 'SvB_BS_184', 'SvB_BS_211',
             'SvB_BS_212', 'SvB_BS_307', 'SvB_BS_197', 'SvB_BS_293',
             'SvB_BS_273', 'SvB_BS_280', 'SvB_BS_256', 'bstream_031'}
    name3 = {'SvB_BS_300', 'SvB_BS_283', 'bstream_031', 'SvB_BS_307',
             'SvB_BS_293', 'SvB_BS_264', 'SvB_BS_289', 'SvB_BS_156',
             'SvB_BS_247', 'SvB_BS_171', 'SvB_BS_192', 'SvB_BS_244',
             'SvB_BS_245', 'SvB_BS_252', 'SvB_BS_253', 'SvB_BS_293',
             'SvB_BS_264', 'SvB_BS_289', 'bstream_002', 'SvB_BS_285',
             'SvB_BS_292', 'bstream_031', 'bstream_006'}
    for cc, f, g, axf, unts, title, toname, in \
            [('frmt2', 'ddm', 'p_pm', (0.001, 0.0001), ('', ' (%)'),
              'Basic measures per book', name1),
             ('translation', 'ddm', 'p_pm', (0.001, 0.0001), ('', ' (%)'),
              'Basic measures per book', name1),
             ('frmt2', 'p_ma', 'p_nn', (0.0001, 0.0001), (' (%)', ' (%)'),
              'POS rel. freqs., per book, in %', name2),  # *
             ('frmt2', 'p_vb', 'p_jj', (0.0001, 0.0001), (' (%)', ' (%)'),
              'POS rel. freqs., per book, in %', name3)]:  # *
        scatter_raw2(datafr, f, g, wdir + 'strusts', compcats=[cc],
                     title=title, axisfact=axf, unts=unts, toname=toname)


def generate_tables_figures(dicts_dir, res_dir):
    plots_dir = res_dir + 'plots/'
    make_dir(plots_dir)
    rankedlists_dir = res_dir + 'rankings_by_feat/'
    make_dir(rankedlists_dir)
    comparisons = [('frmt2', 'sell', 'strm', '', ''),
                   ('frmt2', 'strm', 'sell', '', ''),
                   ('frmt2', 'sell', 'strm', 'category', 'CRIME'),
                   ('frmt2', 'strm', 'sell', 'category', 'CRIME'),
                   ('frmt2', 'sell', 'strm', 'translation', 'no'),
                   ('frmt2', 'sell', 'strm', 'translation', 'transl'),
                   ('frmt2', 'strm', 'sell', 'translation', 'no'),
                   ('frmt2', 'strm', 'sell', 'translation', 'transl'),
                   ('translation', 'no', 'transl', '', ''),
                   ('translation', 'transl', 'no', '', '')]
    dict_csvs = [dicts_dir + 'gram_relfrqs.csv',
                 dicts_dir + 'lexrich_stats.csv',
                 dicts_dir + 'struct_stats.csv']
    # Generate the comparisons
    make_cles_tables(dict_csvs, comparisons, 645, res_dir)
    # Generate, for each measure, a list of the works ranked by that measure
    make_ranked_lists(dict_csvs, rankedlists_dir)
    # Generate scatter plots based on selected pairs of measures
    make_stylometric_scatter_plots(dicts_dir, plots_dir)


if __name__ == '__main__':
    dictionary_dir = '../dicts/'
    results_dir = '../results/'
    make_dir(results_dir)
    # Step 2: replicates the tables and figures in the article
    # and additional ones from the data compiled in the previous
    # step. That data is supplied.
    generate_tables_figures(dictionary_dir, results_dir)
