from expaux.dataformatting import make_dir
from pop_exps.dict_aux import mk_corpus_check_art1, mk_gram_relfrqs,\
    mk_lexrich_stats, mk_struct_stats
from pop_exps.lex_diversity import mk_lemma_freq_dict


def generate_data_from_corpus(dicts_dir):
    # These steps require access to the corpus
    # which is protected by copyright.
    #
    # Just listing the works for checking
    mk_corpus_check_art1(dicts_dir + 'corpus_check_art1.csv')
    # Compile "structural" features
    mk_struct_stats(dicts_dir + 'struct_stats.csv')
    # Compile lemma (relative) frequencies
    mk_lemma_freq_dict(dicts_dir + 'lemma_freqs.csv')
    # Compile pos relative frequencies (two steps/files)
    mk_gram_relfrqs(dicts_dir + 'gram_relfrqs')
    # Compile relative frequencies based on lexical diversity
    mk_lexrich_stats(dicts_dir + 'lemma_freqs.csv',
                     dicts_dir + 'lexrich_stats.csv')


if __name__ == '__main__':
    dictionary_dir = '../dicts/'
    make_dir(dictionary_dir)
    # This step requires access to the corpus
    # which is protected by copyright
    generate_data_from_corpus(dictionary_dir)
