import csv
import os

encoding_for_dictionary_files = 'utf-8-sig'
separator = '@'  # in word/number dictionary files
separCatSymb = '*'  # in word/number dictionary files


def make_dir(newdir):
    if not os.path.exists(newdir):
        os.makedirs(newdir)
        print('Made directory:', newdir)
    else:
        print('Will use existing directory:', newdir)


def store_on_csv(filen, rows):
    with open(filen, mode='w', newline='', encoding='utf-8') as csvf:
        csvwriter = csv.writer(csvf, delimiter=',', quotechar='"',
                               quoting=csv.QUOTE_MINIMAL)
        for csvrow in rows:
            csvwriter.writerow(csvrow)


class TermEntry:
    """Used internally for frequency sorting."""

    def __init__(self, term, val):
        self.term = term
        self.val = val

    def __lt__(self, other):
        if self.val == other.val:
            return self.term < other.term
        return self.val > other.val

    def as_string(self):
        return self.term + separator + str(self.val)


class TermDict:
    """"For dictionaries of terms associated with numerical values, e.g. frequency."""

    def __init__(self, file=None):
        self._DCTN = {}
        if file is not None:
            line_nr = 0
            with open(file, encoding=encoding_for_dictionary_files) as infile:
                for line in infile:
                    (symb, _, fr) = line.partition(separator)
                    self._DCTN[symb] = int(fr)
                    line_nr = line_nr + 1
            print('TermDict from ' + file + ' (' + str(line_nr) + ' entries)')

    def __iter__(self):
        yield from self._DCTN.items()

    def __getitem__(self, key):
        if key in self._DCTN:
            return self._DCTN[key]
        return 0

    def __setitem__(self, key, val):
        self._DCTN[key] = val

    def put(self, key, val):
        self._DCTN[key] = val

    def keys(self):
        return self._DCTN.keys()

    def keylist(self):
        kl = list(self._DCTN.keys())
        kl.sort()
        return kl

    def keyset(self):
        ks = set(self._DCTN.keys())
        return ks

    def update_dict(self, key, val=1, lowercase=True):
        if lowercase:
            key = key.lower()
        if key in self._DCTN:
            self._DCTN[key] = self._DCTN[key] + val
        else:
            self._DCTN[key] = val

    def top_scored_terms(self, size):
        wordlist = [TermEntry(key, self._DCTN[key])
                    for key in self._DCTN.keys()]
        wordlist.sort()
        return wordlist[0:size]


